#include "mbed.h"
#include "Nav_Switch.h"
#include "uLCD_4DGL.h"

Nav_Switch myNav(p12, p15, p14, p16, p13); // initialize nav switch
uLCD_4DGL uLCD(p9, p10, p11); // initialize uLCD display
BusOut mbedleds(LED1, LED2, LED3, LED4); // initialize LEDs

// Constants for circle movement
const int circle_size = 15;
const int screen_width = 128;
const int screen_height = 128;

// Current position of the circle
int circle_x = screen_width / 2;
int circle_y = screen_height / 2;

// Current color of the circle
int circle_color = 0;

// Array of possible circle colors
int colors[] = {BLUE, RED, GREEN, WHITE};

// Draw the circle at its current position and color
void draw_circle()
{
    uLCD.filled_circle(circle_x, circle_y, circle_size, colors[circle_color]);
}

void draw_circle_blank()
{
    uLCD.filled_circle(circle_x, circle_y, circle_size, BLACK);
}


int main()
{
    // Initialize the display and draw the circle
    uLCD.background_color(BLACK);
    uLCD.cls();
    // draw_circle();
    // mbedleds = 0x0F;
    uLCD.baudrate(3000000);


    while (1) {
        // Read the nav switch and move the circle accordingly
        if (myNav.up()) {
            draw_circle_blank();
            circle_y = max(circle_y - 5, circle_size);
            mbedleds = 0x01;
            
            draw_circle();
            // uLCD.cls();
        } else if (myNav.down()) {
            draw_circle_blank();
            circle_y = min(circle_y + 5, screen_height - circle_size);
            mbedleds = 0x02;
            draw_circle_blank();
            draw_circle();
            // uLCD.cls();
        } else if (myNav.left()) {
            draw_circle_blank();
            circle_x = max(circle_x - 5, circle_size);
            mbedleds = 0x04;
            draw_circle_blank();
            draw_circle();
            // uLCD.cls();
        } else if (myNav.right()) {
            draw_circle_blank();
            circle_x = min(circle_x + 5, screen_width - circle_size);
            mbedleds = 0x08;
            draw_circle_blank();
            draw_circle();
            // uLCD.cls();
        } else if (myNav.center()) {
            draw_circle_blank();
            // Change the color of the circle on center button press
            circle_color = (circle_color + 1) % 4;
            mbedleds = 0x10;
            wait(0.5);
            draw_circle();
            // uLCD.cls();
        } else {
            wait(0.5);
            // mbedleds = ~mbedleds; // Flicker LEDs
            wait(0.5);
            draw_circle();
        }
        
        
    }
}
