//=================================================================
// The main program file.
//
// Copyright 2023 Georgia Tech. All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must NOT be made publicly available anywhere.
//==================================================================


// Projet includes
#include "globals.h"
#include "hardware.h"
#include "map.h"
#include "graphics.h"
#include "speech.h"
#include <math.h>

#define CITY_HIT_MARGIN 1
#define CITY_UPPER_BOUND (SIZE_Y-(LANDSCAPE_HEIGHT+MAX_BUILDING_HEIGHT))

// Helper function declarations
void playSound(char* wav);


/////////////////////////
// Struct of Player 
/////////////////////////

/**
 * The main game state. Must include Player locations and previous locations for
 * drawing to work properly. Other items can be added as needed.
 */
struct {
    int x,y;            // Current locations
    int px, py;         // Previous locations
    int score;          // Current
    int lives;          // Number of lives
    bool is_talking_to_npc; //flag when currently talking to npc
    bool has_key;       // flag when obtained the key
    bool game_solved;   // flag when game is complete
    bool talked_to_npc; // flag when you've talked to npc
    bool has_gunter_helmet; //flag when defeated gunter
    bool has_lemon;      //flag when lemongrab is defeated
    bool jump_mode;      //jump mode


    //You will need to add more flags as needed

} Player;



/////////////////////////
// Get Action
/////////////////////////

/**
 * Given the game inputs, determine what kind of update needs to happen.
 * Possible return values are defined below.
 * Get Actions from User (pushbuttons, and nav_switch)
 * Based on push button and navigation switch inputs, determine which action
 * needs to be performed (may be no action).
 */
#define NO_ACTION 0
#define ACTION_BUTTON 1
#define JUMP_BUTTON 2
#define ATTACK_BUTTON 3
#define GO_LEFT 4
#define GO_RIGHT 5
#define GO_UP 6
#define GO_DOWN 7
#define INVENTORY 8

//Draw game inputs
#define NO_RESULT 0
#define GAME_OVER 1
#define FULL_DRAW 2


int get_action(GameInputs inputs)
{
    //******************
    // TODO: Implement
    //******************
    
    // 1. Check your action and menu button inputs and return the corresponding action value
    
    // 2. Check for your navigation switch inputs and return the corresponding action value
    
    // If no button is pressed, just return no action value

    if (inputs.b1 && !inputs.b2 && !inputs.b3) {
        return ACTION_BUTTON;
    } else if (!inputs.b1 && inputs.b2 && !inputs.b3) {
        return JUMP_BUTTON;
    } else if (!inputs.b1 && !inputs.b2 && inputs.b3) {
        return ATTACK_BUTTON;
    } else if (inputs.ns_left) {
        return GO_LEFT;
    } else if (inputs.ns_right) {
        return GO_RIGHT;
    } else if (inputs.ns_up) {
        return GO_UP;
    } else if (inputs.ns_down) {
        return GO_DOWN;
    } else if (inputs.ns_center) {
        return INVENTORY;
    }

    return NO_ACTION;
}



/////////////////////////
// Draw Game
/////////////////////////

/**
 * Entry point for frame drawing. This should be called once per iteration of
 * the game loop. This draws all tiles on the screen, followed by the status 
 * bars. Unless init is nonzero, this function will optimize drawing by only 
 * drawing tiles that have changed from the previous frame.
 */
void draw_game(int init)
{
    // Draw game border first
    if(init) draw_border();

    draw_header(Player.x, Player.y, Player.score, Player.lives, Player.jump_mode);
    
    // Iterate over all visible map tiles
    for (int i = -5; i <= 5; i++) // Iterate over columns of tiles
    {
        for (int j = -4; j <= 4; j++) // Iterate over one column of tiles
        {
            // Here, we have a given (i,j)
            
            // Compute the current map (x,y) of this tile
            int x = i + Player.x;
            int y = j + Player.y;
            
            // Compute the previous map (px, py) of this tile
            int px = i + Player.px;
            int py = j + Player.py;
                        
            // Compute u,v coordinates for drawing
            int u = (i+5)*11 + 3;
            int v = (j+4)*11 + 15;
            
            // Figure out what to draw
            DrawFunc draw = NULL;
//            if (init && i == 0 && j == 0) // Only draw the player on init
            if ( i == 0 && j == 0) // always draw the player
            {
                draw_player(u, v, Player.has_key);


                // Walking under tree
                MapItem* prev_item = get_here(px, py);
                if (prev_item-> type == BIG_TREE1)
                {
                    draw_bigtree1(u, v);
                } 
                else if (prev_item-> type == BIG_TREE2)
                {
                    draw_bigtree2(u, v);
                } 
                //


                continue;
            }
            else if (x >= 0 && y >= 0 && x < map_width() && y < map_height()) // Current (i,j) in the map
            {
                MapItem* curr_item = get_here(x, y);
                MapItem* prev_item = get_here(px, py);
                if (init || curr_item != prev_item) // Only draw if they're different
                {
                    if (curr_item) // There's something here! Draw it
                    {
                        draw = curr_item->draw;
                    }
                    else // There used to be something, but now there isn't
                    {
                        draw = draw_nothing;
                    }
                }
                else if (curr_item && curr_item->type == CLEAR)
                {
                    // This is a special case for erasing things like doors.
                    draw = curr_item->draw; // i.e. draw_nothing
                }
            }
            else if (init) // If doing a full draw, but we're out of bounds, draw the walls.
            {
                draw = draw_wall;
            }

            // Actually draw the tile
            if (draw) draw(u, v);
        }
    }

    // Draw status bars    
    draw_upper_status();
    draw_lower_status();
}



/////////////////////////
// Helper Functions:
/////////////////////////
// Feel free to define any helper functions here for update game

//NEWCHECK
void is_talking_to_npc (int x, int y) {
    Player.is_talking_to_npc = true; 
    add_npc(x, y, true);   //NEWCHECK
    draw_game(FULL_DRAW);

    //GIVE INSTRUCTIONS SPEECH BUBBLE
    if (Player.game_solved) {
        Player.has_key = true;
        speech("You have won", "Thanks you the best");
        speech("Go home", "");
        Player.score += 50;
    } else if (Player.has_gunter_helmet) {
        //Case gunter killed then talking to the NPC
        speech("You have earned", "the right");
        speech("to learn ", "the secret");
        speech("You shall have", "the power of");
        speech("The Stinging ", "Strike");
        speech("Now bring me the", "Ice King's crown");
                        
    } else {
        //Case first go to talk to NPC
        speech("If you want to","prove yourself");
        speech("worthy.", "Defeat");
        speech("The Ice King!", "His lair is");
        speech("nearby...", "");
        speech("To beat him you", "need to learn");
        speech("the Stinging ", "Strike");
        speech("Bring me ", "gunter's helmet");
        speech("and I shall teach", "you my secret");
    }

    Player.is_talking_to_npc = false;
    add_npc(x, y, false);
}

void npc_method (int x, int y) {  //NEWCHECK

    Player.talked_to_npc = true;

    int eastType = get_east(x,y) -> type;
    int westType = get_west(x,y) -> type;
    int northType = get_north(x,y) -> type;
    int southType = get_south(x,y) -> type;

    if (eastType == NPC) {
        is_talking_to_npc(x + 1, y);
    } else if (westType == NPC) {
        is_talking_to_npc(x - 1, y);
    } else if (northType == NPC) {
        is_talking_to_npc(x, y - 1);
    } else if ( southType == NPC) {
        is_talking_to_npc(x, y + 1);
    }


}

/** 
 * Given the player's current coordinates, it returns the type associated with the next action
 *
 * Returns the associated integer value of the type. 
 */ 
int nearby_return(int x, int y) {

    int eastType = get_east(x,y) -> type;
    int westType = get_west(x,y) -> type;
    int northType = get_north(x,y) -> type;
    int southType = get_south(x,y) -> type;
    int currType = get_here(x, y) -> type;


//NEWCHECK
    if ((eastType == NPC) || (westType == NPC) || (northType == NPC) || (southType == NPC)) {
        return NPC;
    } else if ((eastType == DOOR) || (westType == DOOR) || (northType == DOOR) || (southType == DOOR)) {
        return DOOR;
    } else if (currType == CAVE) {
        return CAVE;
    } else if (currType == STAIRS) {
        return STAIRS;
    }

    return 0;

}

void gunter_dead_emote(int x, int y) {
    add_fire(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_gunter_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_fire(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_gunter_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_fire(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
}

void lemongrab_dead_emote(int x, int y) {
    add_earth(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_lemongrab_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_earth(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_lemongrab_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_earth(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
}

void iceking_dead_emote(int x, int y) {
    add_water(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_ice_king_main_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_lemon(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_ice_king_main_enemy(x, y);
    draw_game(FULL_DRAW);
    wait(0.5);
    add_fire(x, y);;
    draw_game(FULL_DRAW);
    wait(0.5);
}


/* Successfully attacks the enemy
*/

int attack_gunter_enemy(int x, int y) {

    int eastType = get_east(x,y) -> type;
    int westType = get_west(x,y) -> type;
    int northType = get_north(x,y) -> type;
    int southType = get_south(x,y) -> type;
    int currType = get_here(x, y) -> type;


    if (eastType == GUNTER_ENEMY) {
        gunter_dead_emote(x + 1, y);
        add_slain_gunter(x + 1, y);
        return 1;
    } else if (westType == GUNTER_ENEMY) {
        gunter_dead_emote(x - 1, y);
        add_slain_gunter(x - 1, y);
        return 1;
    } else if (northType == GUNTER_ENEMY) {
        gunter_dead_emote(x , y - 1);
        add_slain_gunter(x , y - 1);
        return 1;
    } else if (southType == GUNTER_ENEMY) {
        gunter_dead_emote(x , y + 1);
        add_slain_gunter(x , y + 1);
        return 1;
    }

    return 0; 
}


int attack_lemongrab_enemy(int x, int y) {

    int eastType = get_east(x,y) -> type;
    int westType = get_west(x,y) -> type;
    int northType = get_north(x,y) -> type;
    int southType = get_south(x,y) -> type;
    int currType = get_here(x,y) -> type;


    if (eastType == LEMONGRAB_ENEMY) {
        lemongrab_dead_emote(x + 1, y);
        add_slain_gunter(x + 1, y);
        return 1;
    } else if (westType == LEMONGRAB_ENEMY) {
        lemongrab_dead_emote(x - 1, y);
        add_slain_gunter(x - 1, y);
        return 1;
    } else if (northType == LEMONGRAB_ENEMY) {
        lemongrab_dead_emote(x , y - 1);
        add_slain_gunter(x , y - 1);
        return 1;
    } else if (southType == LEMONGRAB_ENEMY) {
        lemongrab_dead_emote(x , y + 1);
        add_slain_gunter(x , y + 1);
        return 1;
    }

    return 0; 
}


int attack_ice_king_enemy(int x, int y) {

    int eastType = get_east(x,y) -> type;
    int westType = get_west(x,y) -> type;
    int northType = get_north(x,y) -> type;
    int southType = get_south(x,y) -> type;
    int currType = get_here(x,y) -> type;


    if (eastType == ICE_KING_MAIN_ENEMY) {
        if (Player.has_lemon) {
            iceking_dead_emote(x + 1, y);
            add_slain_ice_king(x + 1, y);
        }
        return 1;
    } else if (westType == ICE_KING_MAIN_ENEMY) {
        if (Player.has_lemon) {
            iceking_dead_emote(x - 1, y);
            add_slain_ice_king(x - 1, y);
        }
        return 1;
    } else if (northType == ICE_KING_MAIN_ENEMY) {
        if (Player.has_lemon) {
            iceking_dead_emote(x , y - 1);
            add_slain_ice_king(x , y - 1);
        }
        return 1;
    } else if (southType == ICE_KING_MAIN_ENEMY) {
        if (Player.has_lemon) {
            iceking_dead_emote(x, y + 1);
            add_slain_ice_king(x, y + 1);
        }
        return 1;
    }

    return 0; 
}


void poison_plant_freeze() {
    speech("Poison Plant Attack", "3s recovery");
    wait(3);
    Player.score -= 30;
    Player.lives -= 1;
    draw_game(FULL_DRAW);
}

/////////////////////////
// Update Game
/////////////////////////

/**
 * Update the game state based on the user action. For example, if the user
 * requests GO_UP, then this function should determine if that is possible by
 * consulting the map, and update the Player position accordingly.
 * 
 * Return values are defined below. FULL_DRAW indicates that for this frame,
 * draw_game should not optimize drawing and should draw every tile, even if
 * the player has not moved.
 */
int update_game(int action)
{
    
    if (Player.lives <= 0) {
        return GAME_OVER;
    }
    // Save player previous location before updating
    Player.px = Player.x;
    Player.py = Player.y;
    
    MapItem* item = NULL;
    

    //******************
    // TODO: Implement
    //******************

    
    // Do different things based on the each action.
    // You can define functions like "go_up()" that get called for each case.

    switch(action)
    {
        case GO_UP:
            //TODO: Implement
            //1. Check the item north of the player
            //2. Make sure to not walk through walls
            //3. If it is not a wall, the walk up by updating player's coordinates

            if (Player.jump_mode) {
                item = get_north(Player.x, Player.y - 1);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.y -= 2;
                }

            } else {
                item = get_north(Player.x, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.y -= 1 ;
                }
            }

            return FULL_DRAW;
            break;
            
        case GO_LEFT:
            //TODO: Implement
            if (Player.jump_mode) {
                item = get_west(Player.x - 1, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.x -= 2;
                }

            } else {
                item = get_west(Player.x, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.x -= 1 ;
                }
            }

            return FULL_DRAW;
            break;
            
        case GO_DOWN:
            //TODO: Implement
            if (Player.jump_mode) {
                item = get_south(Player.x, Player.y + 1);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.y += 2;
                }

            } else {
                item = get_south(Player.x, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.y += 1 ;
                }
            }

            return FULL_DRAW;
            break;
            
        case GO_RIGHT:
            //TODO: Implement

            if (Player.jump_mode) {
                item = get_east(Player.x + 1, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.x += 2;
                }

            } else {
                item = get_east(Player.x, Player.y);
                if (item -> type == PLANT) {
                    poison_plant_freeze();
                }

                if (item -> walkable) {
                    Player.x += 1 ;
                }
            }


            return FULL_DRAW;
            break;

        case INVENTORY:
            //NEWCHECK
            draw_inventory(Player.has_gunter_helmet, Player.has_lemon, Player.game_solved, Player.has_key );
            draw_game(FULL_DRAW);
            break;

        case JUMP_BUTTON:

            Player.jump_mode = !Player.jump_mode;
            speech("Jump button", "");

        break;   

        case ACTION_BUTTON:

            //******************
            // TODO: Implement
            //******************

            // 1. Check if near NPC, 
            //     - if so, mark the player has talked and give instructions on what to do
            //     - if the game is solved (defeated Buzz), give the player the key
            //     - return FULL_DRAW to redraw the scene


            // 2. Check if near a door
            //    - if the player has the key, you win the game
            //    - if not, show speech bubbles that the play needs to get the key 
            //     -return FULL_DRAW to redraw the scene
            


            // 3. Check if on Pete's cave
            //    - if the player has talked to the npc, then start the speech bubble to fight buzz
            //    - set the players coordinates for the small map
            //    - and set the map to the small map
            //     -return FULL_DRAW to redraw the scene

            
            // 4. Check if on a stairs
            //    - if so, move the player the correct coordinates
            //    - and set the map back to the main big map
            //     -return FULL_DRAW to redraw the scene


            // Feel free to add more functions as you make the game!

            
            switch(nearby_return(Player.x, Player.y)) 
            {

            // 1. Check if near NPC, 
            //     - if so, mark the player has talked and give instructions on what to do
            //     - if the game is solved (defeated Buzz), give the player the key
            //     - return FULL_DRAW to redraw the scene
                case (NPC):
                    
                    //NEWCHECK
                    npc_method(Player.x, Player.y);
                    return FULL_DRAW;
                    break;


            // 2. Check if near a door
            //    - if the player has the key, you win the game
            //    - if not, show speech bubbles that the play needs to get the key 
            //     -return FULL_DRAW to redraw the scene
            

                case (DOOR):

                    if (Player.has_key) {
                        return GAME_OVER;
                    }
                    
                    break;


            // 3. Check if on Pete's cave
            //    - if the player has talked to the npc, then start the speech bubble to fight buzz
            //    - set the players coordinates for the small map
            //    - and set the map to the small map
            //     -return FULL_DRAW to redraw the scene


                case (CAVE):

                    if (Player.has_gunter_helmet) {
                        //FIGHT BUZZ SPEECH BUBBLE
                        //set the players coordinates for the small map
                        speech("You are entering", "the cave.");
                        speech("Defeat the", "Ice King");
                        speech("by using the", "Special Move");

                        Player.x = 7;
                        Player.y = 8;

                        set_active_map(1);
                        return FULL_DRAW; 
                    }
                    break;


            // 4. Check if on a stairs
            //    - if so, move the player the correct coordinates
            //    - and set the map back to the main big map
            //     -return FULL_DRAW to redraw the scene

                case (STAIRS):

                    // MOVE PLAYER TO CORRECT COORDINATES
                    if (Player.game_solved) {
                        //FIGHT BUZZ SPEECH BUBBLE
                        //set the players coordinates for the small map
                        speech("You are done", "EXIT");

                        Player.x = 5;
                        Player.y = 20;

                        set_active_map(0);
                        return FULL_DRAW; 
                    }
                    break;
            }


        break; 


        
        case ATTACK_BUTTON:

            //******************
            // TODO: Implement
            //******************

            // 1. Check if near enemy, 
            //     - if so, mark enemy as defeated
            //      use speech bubbled to show what item was dropped
            //      update the player struct as needed
            //      if enemy is Pete, make sure that the right attack is being used
            //      If pete is defeated, update game as nescessary
    
            if ((Player.talked_to_npc) && (attack_gunter_enemy(Player.x, Player.y))) {
                speech("Gunter's Helmet", "Dropped");
                Player.has_gunter_helmet = true; 
                Player.score += 20;
                break;
            } else if ((attack_lemongrab_enemy(Player.x, Player.y))) {
                speech("Lemon", "Dropped");
                Player.has_lemon = true; 
                Player.score += 30;
                break;
            } else if ((!Player.has_lemon) && (attack_ice_king_enemy(Player.x, Player.y))) {
                speech("Life lost", "Wrong attack" );
                speech("Go get Lemon", "from Lemongrab");
                Player.lives -= 1;
                break;
            } else if ((Player.has_lemon) && (attack_ice_king_enemy(Player.x, Player.y))) {
                speech("ice King", "defeated");
                speech("Go back", "to NPC");
                Player.game_solved = true;
                Player.score += 50;
                break;
            } 

            break;

        //***********
        // Add more cases as needed
        //***********
    }
    
    return NO_RESULT;
}




/////////////////////////
// Map Intialization
/////////////////////////

// Important locations for all maps
int cb_loc[2] = {5,20}; //Location of the center of the cave


/**
 * Initialize the main world map. Add walls around the edges, interior chambers,
 * and plants in the background so you can see motion.
 */
void init_main_map()
{
    //Initialize and sets current map to the first map
    Map* map = set_active_map(0);

    /////////////////////////
    //Initial Environmnet
    /////////////////////////

    // Adding decor
    /* for (int i = 1; i <= 48; i++) {
        for (int j = 1; j<= 48; j++)
        add_tile(i, j);
    } */

    /* add_tile(1,1);
    add_tile(1,2); */


    //Adding random plants
    pc.printf("Adding Plants!\r\n");
    for(int i = map_width() + 3; i < map_area(); i += 39)
    {
        add_plant(i % map_width(), i / map_width());
    }

    //Adding wall borders 
    pc.printf("Adding walls!\r\n");
    add_wall(0,              0,              HORIZONTAL, map_width());
    add_wall(0,              map_height()-1, HORIZONTAL, map_width());
    add_wall(0,              0,              VERTICAL,   map_height());
    add_wall(map_width()-1,  0,              VERTICAL,   map_height());
    
    //Adding extra chamber borders 
    pc.printf("Add extra chamber\r\n");
    add_wall(30, 0, VERTICAL, 10);
    add_wall(30, 10, HORIZONTAL, 10);
    add_wall(39, 0, VERTICAL, 10);
    add_door(33, 10, HORIZONTAL, 4);

    //Adding extra cave to Buzz's evil lair
    pc.printf("Add cave\r\n");
    add_cave(cb_loc[0],cb_loc[1],1,1,5,5);      //Cave is set as a 4x4 block to be bigger
    add_cave(cb_loc[0]+1,cb_loc[1],2,1,5,5);
    add_cave(cb_loc[0],cb_loc[1]+1,3,1,5,5);
    add_cave(cb_loc[0]+1,cb_loc[1]+1,4,1,5,5);

    pc.printf("Initial environment completed\r\n");

    /////////////////////////////////
    // Characters and Items for the map
    /////////////////////////////////

    // Add NPC
    add_npc(10, 5, Player.is_talking_to_npc);  //NPC is initialized to (x,y) = 10, 5. Feel free to move him around
    add_gunter_enemy(15, 5);  //Gunther initialized
    add_bigtree1(13, 8);
    add_bigtree2(13, 9);
    
    //***********************************
    // TODO: Implement As Needed
    //***********************************

    //Add any extra characters/items here for your project




    //Prints out map
    print_map();
}







void init_small_map()
{
    //Sets current map to the second map
    set_active_map(1);

    //Initialize and sets current map to the first map
    Map* map = set_active_map(1);

    //***********************************
    // TODO: Implement 
    //***********************************

    // 1. Add walls to the smaller map.
    //    Set the dimensions to be 16x16  <-- you may change to your liking, but must be smaller than the main map
    //    Hint: See how walls are initialized in the main map

    //Adding wall borders 
    pc.printf("Adding walls!\r\n");
    add_wall(0,              0,              HORIZONTAL, map_width());
    add_wall(0,              map_height()-1, HORIZONTAL, map_width());
    add_wall(0,              0,              VERTICAL,   map_height());
    add_wall(map_width()-1,  0,              VERTICAL,   map_height());

    //
    // 2. Add a way to access your specail attacks either here or in update_game() or anywhere you feel would be the best
    //
    // 3. Add Boss in the map


    // You may add any extra characters/items here for your project
    // Adding decor
    for (int i = 7; i <= 14; i++) {
        for (int j = 1; j<= 7; j++)
        add_water(i, j);
    }

    for (int i = 7; i <= 14; i++) {
        for (int j = 8; j<= 14; j++)
        add_fire(i, j);
    }

    for (int i = 1; i <= 6; i++) {
        for (int j = 1; j<= 14; j++)
        add_earth(i, j);
    }

    /*for (int i = 7; i <= 14; i++) {
        add_water(i, 7);
    } 
    for (int i = 1; i <= 7; i++) {
        add_water(7, i);
    } 
    for (int i = 1; i <= 7; i++) {
        add_water(14, i);
    } */

    // Adding decor
    /*
    for (int i = 7; i <= 14; i++) {
        add_fire(i, 8);
    }
    for (int i = 7; i <= 14; i++) {
        add_fire(i, 14);
    }
    for (int i = 8; i <= 14; i++) {
        add_fire(7, i);
    } 
    for (int i = 8; i <= 14; i++) {
        add_fire(14, i);
    } */ 


    // Add stairs back to main (map 0)
    add_stairs(4, 6, 0, cb_loc[0], cb_loc[1]);
    add_lemongrab_enemy(10, 11 ); 
    add_ice_king_main_enemy(10, 4); 
    
}


/**
 * Program entry point! This is where it all begins.
 * This function orchestrates all the parts of the game. Most of your
 * implementation should be elsewhere - this holds the game loop, and should
 * read like a road map for the rest of the code.
 */
int main()
{
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");


    // Start Page

    draw_start_page();

    while (button1) {

        if (!button2) {
            draw_controls();
            draw_start_page();
            wait(2);
        } 
        wait_ms(30);
        
    }



    //uLCD.filled_rectangle(64, 64, 74, 74, YELLOW); //DELETE OR COMMENT THIS LINE  <-- It is a temporary indicator that your LCD is working before you implement your code
    //<------ DELETE THIS LINE

    //Initialize the maps
    maps_init();
    init_main_map();
    init_small_map();
    
    // Initialize game state
    set_active_map(0);
    Player.x = Player.y = 5;
    Player.has_key = false;
    Player.game_solved = false;
    Player.talked_to_npc = false;
    Player.jump_mode = false;
    Player.lives = 3;

    // Initial drawing
    draw_game(true);

    // Main game loop
    while(1)
    {

        ////////////////////////////////
        // TODO: Implement 
        ////////////////////////////////

        // Timer to measure game update speed
        Timer t; t.start();
        
        // Actually do the game update:
        // 1. Read inputs  
        GameInputs inputs = read_inputs();      

        // 2. Determine action (get_action) 
        int currAction = get_action(inputs);      

        // 3. Update game (update_game)
        int result = update_game(currAction);  // Set this variable "result" for the resulting state after update game

        // 3b. Check for game over based on update game result
        if (result == GAME_OVER) {
            //DONE CODE THIS 
            
            if (Player.has_key) {
                draw_game_over();
            } else {
                draw_lost();
            }
            break;
        } else {
            // 4. Draw screen to uLCD
            bool full_draw = false;
            if (result == FULL_DRAW) full_draw = true;
            draw_game(full_draw);
        }
        
        // 5. Frame delay
        t.stop();
        int dt = t.read_ms();
        if (dt < 100) wait_ms(100 - dt);
    }
    //DELETE THIS LINE  ----->*/ 

}




/////////////////////////////
//Advanced Features
/////////////////////////////

// Plays a wavfile
void playSound(char* wav)
{
    //open wav file
    FILE *wave_file;
    wave_file=fopen(wav,"r");
    
    if(wave_file != NULL) 
    {
        printf("File opened successfully\n");

        //play wav file
        printf("Sound playing...\n");
        waver.play(wave_file);
    
        //close wav file
        printf("Sound stopped...\n");
        fclose(wave_file);
        return;
    }
    
    printf("Could not open file for reading - %s\n", wav);
    return;
}

