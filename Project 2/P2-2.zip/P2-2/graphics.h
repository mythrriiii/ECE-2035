// ============================================
// The graphics header file
//
// Copyright 2023 Georgia Tech. All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must NOT be made publicly available anywhere.
//==================================================================

#ifndef GRAPHICS_H
#define GRAPHICS_H

/**
 * Takes a string image and draws it to the screen. The string is 121 characters
 * long, and represents an 11x11 tile in row-major ordering (across, then down,
 * like a regular multi-dimensional array). The available colors are:
 *      R = Red
 *      Y = Yellow
 *      G = Green
 *      D = Brown ("dirt")
 *      5 = Light grey (50%)
 *      3 = Dark grey (30%)
 *      Any other character is black
 * More colors can be easily added by following the pattern already given.
 */
void draw_img(int u, int v, const char* img);

/**
 * Draws the player. This depends on the player state, so it is not a DrawFunc.
 */
void draw_player(int u, int v, int key);

/**
 * Draw the upper status bar.
 */
void draw_upper_status();

/**
 * Draw the lower status bar.
 */ 
void draw_lower_status();

/**
 * Draw the border for the map.
 */
void draw_border();


/**
 * Draw the game over.
 */
void draw_game_over();

/**
 * DrawFunc functions. 
 * These can be used as the MapItem draw functions.
 */
void draw_nothing(int u, int v);
void draw_wall(int u, int v);
void draw_plant(int u, int v);
void draw_mud(int u, int v);
void draw_door(int u, int v);
void draw_npc1(int u, int v);
void draw_npc2(int u, int v);
void draw_stairs(int u, int v);
void draw_tile(int u, int v);
void draw_cave1(int u, int v);
void draw_cave2(int u, int v);
void draw_cave3(int u, int v);
void draw_cave4(int u, int v);
void draw_water(int u , int v);
void draw_fire(int u , int v);
void draw_earth(int u , int v);
void draw_lemon (int u , int v);
void draw_buzz(int u, int v);
void draw_gunter(int u, int v);
void draw_ice_king(int u, int v);
void draw_lemongrab(int u, int v);
void draw_header(int x, int y, int score, int lives, bool jump);
void draw_bigtree1(int x, int y);
void draw_bigtree2(int x, int y);
void draw_inventory(bool has_helmet, bool has_lemon, bool game_solved, bool has_key);
void inventory_wait();
void inventory_item(const char* title, const char* line1, const char* line2, const char* line3, const char* line4, const char* line5);
void inventory_write(const char* itemLines[]);
void inventory_bg_setup();
void draw_start_page();
void draw_controls();
void draw_up(int x, int y);
void draw_down(int x, int y);
void draw_left(int x, int y);
void draw_right(int x, int y);
void draw_button(int x, int y);
void draw_lost();



#endif // GRAPHICS_H